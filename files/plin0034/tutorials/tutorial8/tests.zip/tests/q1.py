from otter.test_files import test_case

OK_FORMAT = False

name = "q1"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_parsing_base_case_desc(line, ret_value, fn_name):
    test_strs = '''
def test_parsing_base_case(test_wcfg, test_sentence, create_table, parsing_base_case):
    n = len(test_sentence)
    all_non_terminals = set((rule[0] for rule in test_wcfg.keys()))
    all_terminals = set((rule[1] for rule in test_wcfg.keys() if len(rule) == 2))
    mod_sentence = [word if word in all_terminals else 'UNK' for word in test_sentence]
    table = create_table(n, all_non_terminals, EMPTY_ENTRY)
    parsing_base_case(table, test_wcfg, mod_sentence)

    def valid_cell(cell):
        assert all((isinstance(x, tuple) for x in cell.values())) == True
        assert all((len(x) == 3 for x in cell.values())) == True
        assert all((isinstance(x[0], float) for x in cell.values())) == True
        assert all((isinstance(x[1], int) for x in cell.values())) == True
        assert all((isinstance(x[2], tuple) for x in cell.values())) == True
        assert all((len(x[2]) in [2, 3] for x in cell.values())) == True
    for i in range(n):
        assert table[i][i + 1]['P'][0] == 0.0
        assert table[i][i + 1]['S'][0] == log(0.2)
        valid_cell(table[i][i + 1])
        for j in range(i + 2, n + 1):
            valid_cell(table[i][j])
            assert all((score < -10000 for score, _, _ in table[i][j].values())) == True
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_parsing_base_case(test_wcfg, test_sentence, create_table, parsing_base_case):
    n = len(test_sentence)
    all_non_terminals = set((rule[0] for rule in test_wcfg.keys()))
    all_terminals = set((rule[1] for rule in test_wcfg.keys() if len(rule) == 2))
    mod_sentence = [word if word in all_terminals else 'UNK' for word in test_sentence]
    table = create_table(n, all_non_terminals, EMPTY_ENTRY)
    parsing_base_case(table, test_wcfg, mod_sentence)

    def valid_cell(cell):
        assert all((isinstance(x, tuple) for x in cell.values())) == True, test_parsing_base_case_desc(9, all((isinstance(x, tuple) for x in cell.values())), "all((isinstance(x, tuple) for x in cell.values()))")
        assert all((len(x) == 3 for x in cell.values())) == True, test_parsing_base_case_desc(10, all((len(x) == 3 for x in cell.values())), "all((len(x) == 3 for x in cell.values()))")
        assert all((isinstance(x[0], float) for x in cell.values())) == True, test_parsing_base_case_desc(11, all((isinstance(x[0], float) for x in cell.values())), "all((isinstance(x[0], float) for x in cell.values()))")
        assert all((isinstance(x[1], int) for x in cell.values())) == True, test_parsing_base_case_desc(12, all((isinstance(x[1], int) for x in cell.values())), "all((isinstance(x[1], int) for x in cell.values()))")
        assert all((isinstance(x[2], tuple) for x in cell.values())) == True, test_parsing_base_case_desc(13, all((isinstance(x[2], tuple) for x in cell.values())), "all((isinstance(x[2], tuple) for x in cell.values()))")
        assert all((len(x[2]) in [2, 3] for x in cell.values())) == True, test_parsing_base_case_desc(14, all((len(x[2]) in [2, 3] for x in cell.values())), "all((len(x[2]) in [2, 3] for x in cell.values()))")
    for i in range(n):
        assert table[i][i + 1]['P'][0] == 0.0, test_parsing_base_case_desc(16, table[i][i + 1]['P'][0], "table[i][i + 1]['P'][0]")
        assert table[i][i + 1]['S'][0] == log(0.2), test_parsing_base_case_desc(17, table[i][i + 1]['S'][0], "table[i][i + 1]['S'][0]")
        valid_cell(table[i][i + 1])
        for j in range(i + 2, n + 1):
            valid_cell(table[i][j])
            assert all((score < -10000 for score, _, _ in table[i][j].values())) == True, test_parsing_base_case_desc(21, all((score < -10000 for score, _, _ in table[i][j].values())), "all((score < -10000 for score, _, _ in table[i][j].values()))")


def test_parsing_inductive_case_desc(line, ret_value, fn_name):
    test_strs = '''
def test_parsing_inductive_case(test_sentence, test_wcfg, create_table, parsing_base_case, parsing_inductive_case):
    n = len(test_sentence)
    all_non_terminals = set((rule[0] for rule in test_wcfg.keys()))
    all_terminals = set((rule[1] for rule in test_wcfg.keys() if len(rule) == 2))
    mod_sentence = [word if word in all_terminals else 'UNK' for word in test_sentence]
    table = create_table(n, all_non_terminals, EMPTY_ENTRY)
    parsing_base_case(table, test_wcfg, mod_sentence)
    parsing_inductive_case(table, test_wcfg, mod_sentence)
    for i in range(n):
        assert table[i][i + 1]['P'][0] == 0.0
        assert table[i][i + 1]['S'][0] == log(0.2)
        for j in range(i + 2, n):
            assert table[i][j]['L'][0] > -10000
            assert table[i][j]['P'][0] < -10000
            if j - i == 2:
                assert table[i][j]['S'][0] < -10000
            else:
                assert table[i][j]['S'][0] > -10000
    table_0_n_expected = {'L': (-3.372609924810243, 4, ('L', 'L', 'P')), 'S': (-3.372609924810243, 1, ('S', 'P', 'L')), 'P': EMPTY_ENTRY}
    assert table[0][n] == table_0_n_expected
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_parsing_inductive_case(test_sentence, test_wcfg, create_table, parsing_base_case, parsing_inductive_case):
    n = len(test_sentence)
    all_non_terminals = set((rule[0] for rule in test_wcfg.keys()))
    all_terminals = set((rule[1] for rule in test_wcfg.keys() if len(rule) == 2))
    mod_sentence = [word if word in all_terminals else 'UNK' for word in test_sentence]
    table = create_table(n, all_non_terminals, EMPTY_ENTRY)
    parsing_base_case(table, test_wcfg, mod_sentence)
    parsing_inductive_case(table, test_wcfg, mod_sentence)
    for i in range(n):
        assert table[i][i + 1]['P'][0] == 0.0, test_parsing_inductive_case_desc(9, table[i][i + 1]['P'][0], "table[i][i + 1]['P'][0]")
        assert table[i][i + 1]['S'][0] == log(0.2), test_parsing_inductive_case_desc(10, table[i][i + 1]['S'][0], "table[i][i + 1]['S'][0]")
        for j in range(i + 2, n):
            assert table[i][j]['L'][0] > -10000, test_parsing_inductive_case_desc(12, table[i][j]['L'][0], "table[i][j]['L'][0]")
            assert table[i][j]['P'][0] < -10000, test_parsing_inductive_case_desc(13, table[i][j]['P'][0], "table[i][j]['P'][0]")
            if j - i == 2:
                assert table[i][j]['S'][0] < -10000, test_parsing_inductive_case_desc(15, table[i][j]['S'][0], "table[i][j]['S'][0]")
            else:
                assert table[i][j]['S'][0] > -10000, test_parsing_inductive_case_desc(17, table[i][j]['S'][0], "table[i][j]['S'][0]")
    table_0_n_expected = {'L': (-3.372609924810243, 4, ('L', 'L', 'P')), 'S': (-3.372609924810243, 1, ('S', 'P', 'L')), 'P': EMPTY_ENTRY}
    assert table[0][n] == table_0_n_expected, test_parsing_inductive_case_desc(19, table[0][n], "table[0][n]")


def test_cky_parsing_desc(line, ret_value, fn_name):
    test_strs = '''
def test_cky_parsing(test_sentence, test_wcfg, cky_parsing):
    import nltk
    from IPython.display import display
    predicted_tree = cky_parsing(test_wcfg, test_sentence)
    gold_tree = nltk.Tree('S', [nltk.Tree('P', ['a']), nltk.Tree('L', [nltk.Tree('L', [nltk.Tree('L', [nltk.Tree('P', ['a']), nltk.Tree('P', ['a'])]), nltk.Tree('P', ['a'])]), nltk.Tree('P', ['a'])])])
    print('Predicted Tree')
    display(predicted_tree)
    print('Gold Tree')
    display(gold_tree)
    assert predicted_tree == gold_tree
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_cky_parsing(test_sentence, test_wcfg, cky_parsing):
    import nltk
    from IPython.display import display
    predicted_tree = cky_parsing(test_wcfg, test_sentence)
    gold_tree = nltk.Tree('S', [nltk.Tree('P', ['a']), nltk.Tree('L', [nltk.Tree('L', [nltk.Tree('L', [nltk.Tree('P', ['a']), nltk.Tree('P', ['a'])]), nltk.Tree('P', ['a'])]), nltk.Tree('P', ['a'])])])
    print('Predicted Tree')
    display(predicted_tree)
    print('Gold Tree')
    display(gold_tree)
    assert predicted_tree == gold_tree, test_cky_parsing_desc(9, predicted_tree, "predicted_tree")


from otter.test_files import test_case

OK_FORMAT = False

name = "q2"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_wcfg_desc(line, ret_value, fn_name):
    test_strs = '''
def test_wcfg(wcfg):
    from math import log, exp
    per_terminal_prob = dict()
    for rule, log_prob in wcfg.items():
        assert log_prob <= 0
        per_terminal_prob[rule[0]] = per_terminal_prob.get(rule[0], 0) + exp(log_prob)
    for nt, prob in per_terminal_prob.items():
        assert abs(1 - prob) <= 0.001
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_wcfg(wcfg):
    from math import log, exp
    per_terminal_prob = dict()
    for rule, log_prob in wcfg.items():
        assert log_prob <= 0, test_wcfg_desc(4, log_prob, "log_prob")
        per_terminal_prob[rule[0]] = per_terminal_prob.get(rule[0], 0) + exp(log_prob)
    for nt, prob in per_terminal_prob.items():
        assert abs(1 - prob) <= 0.001, test_wcfg_desc(7, abs(1 - prob), "abs(1 - prob)")


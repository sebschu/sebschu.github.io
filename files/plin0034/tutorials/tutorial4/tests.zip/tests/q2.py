from otter.test_files import test_case

OK_FORMAT = False

name = "q2"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
  return_str = "\n\n"
  return_str += "The last line of the following test program failed.\n"
  return_str += "Make sure that your function returns exactly the same value\n"
  return_str += "as specified in the <b>assert</b> statement.\n\n"
  
  num_spaces = len(lines[2]) - len(lines[2].strip()) 
  return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
  return_str += "\n<b>"
  return_str += lines[line+1][num_spaces:]
  return_str += "</b>\n\n"
  
  return_str += f"{fn_name} returned:\n"
  return_str += str(ret_value)
  return_str += "\n\n"
  
  return return_str  

                                            


@test_case(points=None, hidden=False)
def test_2ab(ans_2a, ans_2b):
  GOLD = {
          "2a": (0.4 * 0.07) / (0.4 * 0.07 + 0.3 * 0.03 + 0.3 * 0.1),
          "2b": (0.3 * 0.9) / (0.3 * 0.9 + 0.3 * 0.97 + 0.4 * 0.93)
         }



  assert ans_2a > GOLD["2a"] - 0.01, "The answer to exercise '2a' is not correct"
  assert ans_2a < GOLD["2a"] + 0.01, "The answer to exercise '2a' is not correct"

  assert ans_2b > GOLD["2b"] - 0.01, "The answer to exercise '2b' is not correct"
  assert ans_2b < GOLD["2b"] + 0.01, "The answer to exercise '2b' is not correct"



@test_case(points=None, hidden=False)
def test_2c(ans_2c):
  GOLD = {
          "2c": (1/3)*0.75**3/((1/3)*0.75**3 + 2/3 * 0.5**3)
         }



  assert ans_2c > GOLD["2c"] - 0.01, "The answer to exercise '2c' is not correct"
  assert ans_2c < GOLD["2c"] + 0.01, "The answer to exercise '2c' is not correct"



@test_case(points=None, hidden=False)
def test_2d(ans_2d):
  GOLD = {
          "2d": (0.4) * (0.05)/ 0.0365
         }



  assert ans_2d > GOLD["2d"] - 0.01, "The answer to exercise '2d' is not correct"
  assert ans_2d < GOLD["2d"] + 0.01, "The answer to exercise '2d' is not correct"




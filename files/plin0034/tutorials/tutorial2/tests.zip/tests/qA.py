from otter.test_files import test_case

OK_FORMAT = False

name = "qA"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
  return_str = "\n\n"
  return_str += "The last line of the following test program failed.\n"
  return_str += "Make sure that your function returns exactly the same value\n"
  return_str += "as specified in the <b>assert</b> statement.\n\n"
  
  return_str += "\n".join([l.strip() for l in lines[2:line+1]])
  return_str += "\n<b>"
  return_str += lines[line+1]
  return_str += "</b>\n\n"
  
  return_str += f"{fn_name} returned:\n"
  return_str += str(ret_value)
  return_str += "\n\n"
  
  return return_str  
 


def alignment_edit_distance_test_desc(line, ret_value, fn_name):
    test_strs = '''
# Test cases

def alignment_edit_distance_test(AlignmentEditDistance):

  a_dist = AlignmentEditDistance()
  c, B = a_dist.compute_edit_distance("musing", "hissing")
  assert c == 3
  l1, l2, l3 = a_dist.compute_alignment(B)
  assert l1[-3:] == "ing"
  assert l2[-3:] == "ing"
  assert l3[-3:] == "   "

  c, B = a_dist.compute_edit_distance("cat", "dog")
  assert c == 3
  l1, l2, l3 = a_dist.compute_alignment(B)
  assert l1 == "cat"
  assert l2 == "dog"
  assert l3 == "sss"

  c, B = a_dist.compute_edit_distance("fan", "spam")
  assert c == 3
  l1, l2, l3 = a_dist.compute_alignment(B)
  assert l1[-2:] == "an"
  assert l2[-2:] == "am"
  assert l3[-2:] == " s"


    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)

@test_case(points=None, hidden=False)
# Test cases

def alignment_edit_distance_test(AlignmentEditDistance):

  a_dist = AlignmentEditDistance()
  c, B = a_dist.compute_edit_distance("musing", "hissing")
  assert c == 3, alignment_edit_distance_test_desc(6, c, "c")
  l1, l2, l3 = a_dist.compute_alignment(B)
  assert l1[-3:] == "ing", alignment_edit_distance_test_desc(8, l1[-3:], "l1[-3:]")
  assert l2[-3:] == "ing", alignment_edit_distance_test_desc(9, l2[-3:], "l2[-3:]")
  assert l3[-3:] == "   ", alignment_edit_distance_test_desc(10, l3[-3:], "l3[-3:]")

  c, B = a_dist.compute_edit_distance("cat", "dog")
  assert c == 3, alignment_edit_distance_test_desc(13, c, "c")
  l1, l2, l3 = a_dist.compute_alignment(B)
  assert l1 == "cat", alignment_edit_distance_test_desc(15, l1, "l1")
  assert l2 == "dog", alignment_edit_distance_test_desc(16, l2, "l2")
  assert l3 == "sss", alignment_edit_distance_test_desc(17, l3, "l3")

  c, B = a_dist.compute_edit_distance("fan", "spam")
  assert c == 3, alignment_edit_distance_test_desc(20, c, "c")
  l1, l2, l3 = a_dist.compute_alignment(B)
  assert l1[-2:] == "an", alignment_edit_distance_test_desc(22, l1[-2:], "l1[-2:]")
  assert l2[-2:] == "am", alignment_edit_distance_test_desc(23, l2[-2:], "l2[-2:]")
  assert l3[-2:] == " s", alignment_edit_distance_test_desc(24, l3[-2:], "l3[-2:]")



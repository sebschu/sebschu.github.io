from otter.test_files import test_case

OK_FORMAT = False

name = "q1"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
  return_str = "\n\n"
  return_str += "The last line of the following test program failed.\n"
  return_str += "Make sure that your function returns exactly the same value\n"
  return_str += "as specified in the <b>assert</b> statement.\n\n"
  
  return_str += "\n".join([l.strip() for l in lines[2:line+1]])
  return_str += "\n<b>"
  return_str += lines[line+1]
  return_str += "</b>\n\n"
  
  return_str += f"{fn_name} returned:\n"
  return_str += str(ret_value)
  return_str += "\n\n"
  
  return return_str  
 


def test_cat_1_desc(line, ret_value, fn_name):
    test_strs = '''
def test_cat_1(Cat):
  my_cat = Cat("Mimi", "black", 6)
  assert my_cat.make_noise() == "meow!"
  assert my_cat.get_info() == "Mimi is 6 years old. Its colour is black."
  my_cat.age_one_year()
  assert my_cat.get_info() == "Mimi is 7 years old. Its colour is black."

    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)

@test_case(points=None, hidden=False)
def test_cat_1(Cat):
  my_cat = Cat("Mimi", "black", 6)
  assert my_cat.make_noise() == "meow!", test_cat_1_desc(2, my_cat.make_noise(), "my_cat.make_noise()")
  assert my_cat.get_info() == "Mimi is 6 years old. Its colour is black.", test_cat_1_desc(3, my_cat.get_info(), "my_cat.get_info()")
  my_cat.age_one_year()
  assert my_cat.get_info() == "Mimi is 7 years old. Its colour is black.", test_cat_1_desc(5, my_cat.get_info(), "my_cat.get_info()")


def test_cat_2_desc(line, ret_value, fn_name):
    test_strs = '''
def test_cat_2(Cat):
  my_cat2 = Cat("Cookie", "grey", 8, has_bell=True)
  assert my_cat2.make_noise() == "ding!"
  my_cat2.age_one_year()
  assert my_cat2.get_info() == "Cookie is 9 years old. Its colour is grey."

    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)

@test_case(points=None, hidden=False)
def test_cat_2(Cat):
  my_cat2 = Cat("Cookie", "grey", 8, has_bell=True)
  assert my_cat2.make_noise() == "ding!", test_cat_2_desc(2, my_cat2.make_noise(), "my_cat2.make_noise()")
  my_cat2.age_one_year()
  assert my_cat2.get_info() == "Cookie is 9 years old. Its colour is grey.", test_cat_2_desc(4, my_cat2.get_info(), "my_cat2.get_info()")


def test_dog_1_desc(line, ret_value, fn_name):
    test_strs = '''
def test_dog_1(Dog):
  my_dog = Dog("Buddy", "brown", 4)
  my_dog.age_one_year()
  my_dog.age_one_year()
  my_dog.age_one_year()
  assert my_dog.make_noise() == "woof!"
  assert my_dog.get_info() == "Buddy is 7 years old. Its colour is brown."
  my_dog.age_one_year()
  assert my_dog.get_info() == "Buddy is 8 years old. Its colour is brown."
  assert my_dog.lead_colour == "brown"

    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)

@test_case(points=None, hidden=False)
def test_dog_1(Dog):
  my_dog = Dog("Buddy", "brown", 4)
  my_dog.age_one_year()
  my_dog.age_one_year()
  my_dog.age_one_year()
  assert my_dog.make_noise() == "woof!", test_dog_1_desc(5, my_dog.make_noise(), "my_dog.make_noise()")
  assert my_dog.get_info() == "Buddy is 7 years old. Its colour is brown.", test_dog_1_desc(6, my_dog.get_info(), "my_dog.get_info()")
  my_dog.age_one_year()
  assert my_dog.get_info() == "Buddy is 8 years old. Its colour is brown.", test_dog_1_desc(8, my_dog.get_info(), "my_dog.get_info()")
  assert my_dog.lead_colour == "brown", test_dog_1_desc(9, my_dog.lead_colour, "my_dog.lead_colour")


def test_dog_2_desc(line, ret_value, fn_name):
    test_strs = '''
def test_dog_2(Dog):
  my_dog2 = Dog("Linus", "black", 5, lead_colour="red")
  assert my_dog2.get_info() == "Linus is 5 years old. Its colour is black."
  assert my_dog2.lead_colour == "red"


    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)

@test_case(points=None, hidden=False)
def test_dog_2(Dog):
  my_dog2 = Dog("Linus", "black", 5, lead_colour="red")
  assert my_dog2.get_info() == "Linus is 5 years old. Its colour is black.", test_dog_2_desc(2, my_dog2.get_info(), "my_dog2.get_info()")
  assert my_dog2.lead_colour == "red", test_dog_2_desc(3, my_dog2.lead_colour, "my_dog2.lead_colour")



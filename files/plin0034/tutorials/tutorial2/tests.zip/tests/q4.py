from otter.test_files import test_case

OK_FORMAT = False

name = "q4"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
  return_str = "\n\n"
  return_str += "The last line of the following test program failed.\n"
  return_str += "Make sure that your function returns exactly the same value\n"
  return_str += "as specified in the <b>assert</b> statement.\n\n"
  
  return_str += "\n".join([l.strip() for l in lines[2:line+1]])
  return_str += "\n<b>"
  return_str += lines[line+1]
  return_str += "</b>\n\n"
  
  return_str += f"{fn_name} returned:\n"
  return_str += str(ret_value)
  return_str += "\n\n"
  
  return return_str  
 


def test_weighted_edit_distance_desc(line, ret_value, fn_name):
    test_strs = '''
def test_weighted_edit_distance(WeightedEditDistance, sub_cost_matrix):
  dist_w = WeightedEditDistance(sub_costs = sub_cost_matrix)
  assert dist_w.compute_edit_distance("bar", "bsr") == 0.25
  assert dist_w.compute_edit_distance("bar", "bfr") == 0.75
  assert dist_w.compute_edit_distance("bwr", "bar") < 0.36
  assert dist_w.compute_edit_distance("bwr", "bar") > 0.34
  assert dist_w.compute_edit_distance("bpr", "bar") == 2
  assert dist_w.compute_edit_distance("power", "pow") == 2
  assert dist_w.compute_edit_distance("deary", "deary") == 0

    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)

@test_case(points=None, hidden=False)
def test_weighted_edit_distance(WeightedEditDistance, sub_cost_matrix):
  dist_w = WeightedEditDistance(sub_costs = sub_cost_matrix)
  assert dist_w.compute_edit_distance("bar", "bsr") == 0.25, test_weighted_edit_distance_desc(2, dist_w.compute_edit_distance("bar", "bsr"), "dist_w.compute_edit_distance(\"bar\", \"bsr\")")
  assert dist_w.compute_edit_distance("bar", "bfr") == 0.75, test_weighted_edit_distance_desc(3, dist_w.compute_edit_distance("bar", "bfr"), "dist_w.compute_edit_distance(\"bar\", \"bfr\")")
  assert dist_w.compute_edit_distance("bwr", "bar") < 0.36, test_weighted_edit_distance_desc(4, dist_w.compute_edit_distance("bwr", "bar"), "dist_w.compute_edit_distance(\"bwr\", \"bar\")")
  assert dist_w.compute_edit_distance("bwr", "bar") > 0.34, test_weighted_edit_distance_desc(4, dist_w.compute_edit_distance("bwr", "bar"), "dist_w.compute_edit_distance(\"bwr\", \"bar\")")
  assert dist_w.compute_edit_distance("bpr", "bar") == 2, test_weighted_edit_distance_desc(6, dist_w.compute_edit_distance("bpr", "bar"), "dist_w.compute_edit_distance(\"bpr\", \"bar\")")
  assert dist_w.compute_edit_distance("power", "pow") == 2, test_weighted_edit_distance_desc(7, dist_w.compute_edit_distance("power", "pow"), "dist_w.compute_edit_distance(\"power\", \"pow\")")
  assert dist_w.compute_edit_distance("deary", "deary") == 0, test_weighted_edit_distance_desc(8, dist_w.compute_edit_distance("deary", "deary"), "dist_w.compute_edit_distance(\"deary\", \"deary\")")


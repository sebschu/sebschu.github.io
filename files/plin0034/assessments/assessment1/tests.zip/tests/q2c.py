from otter.test_files import test_case

OK_FORMAT = False

name = "q2c"
points = 12

def format_error(lines, line, ret_value="", fn_name=""):
  return_str = "\n\n"
  return_str += "The last line of the following test program failed.\n"
  return_str += "Make sure that your function returns exactly the same value\n"
  return_str += "as specified in the <b>assert</b> statement.\n\n"
  
  num_spaces = len(lines[2]) - len(lines[2].strip()) 
  return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
  return_str += "\n<b>"
  return_str += lines[line+1][num_spaces:]
  return_str += "</b>\n\n"
  
  return_str += f"{fn_name} returned:\n"
  return_str += str(ret_value)
  return_str += "\n\n"
  
  return return_str  

                                            


def test_compute_counts_basic_desc(line, ret_value, fn_name):
    test_strs = '''
def test_compute_counts_basic(compute_counts):
  file_paths = {
    "business": "data/bbc-business.txt",
    "entertainment": "data/bbc-entertainment.txt",
    "politics": "data/bbc-politics.txt",
    "tech": "data/bbc-tech.txt",
    "sport": "data/bbc-sport.txt"
  }
  counts = compute_counts(file_paths)


  assert len(counts) == 5
  assert len(counts["business"]) == 14565
  assert counts["business"]["the"] == 10807
  assert counts["entertainment"]["the"] == 8244
  assert counts["politics"]["the"] == 12170
  assert counts["tech"]["the"] == 11663
  assert counts["sport"]["the"] == 9646



    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)

@test_case(points=5, hidden=False)
def test_compute_counts_basic(compute_counts):
  file_paths = {
    "business": "data/bbc-business.txt",
    "entertainment": "data/bbc-entertainment.txt",
    "politics": "data/bbc-politics.txt",
    "tech": "data/bbc-tech.txt",
    "sport": "data/bbc-sport.txt"
  }
  counts = compute_counts(file_paths)


  assert len(counts) == 5, test_compute_counts_basic_desc(11, len(counts), "len(counts)")
  assert len(counts["business"]) == 14565, test_compute_counts_basic_desc(12, len(counts["business"]), "len(counts[\"business\"])")
  assert counts["business"]["the"] == 10807, test_compute_counts_basic_desc(13, counts["business"]["the"], "counts[\"business\"][\"the\"]")
  assert counts["entertainment"]["the"] == 8244, test_compute_counts_basic_desc(14, counts["entertainment"]["the"], "counts[\"entertainment\"][\"the\"]")
  assert counts["politics"]["the"] == 12170, test_compute_counts_basic_desc(15, counts["politics"]["the"], "counts[\"politics\"][\"the\"]")
  assert counts["tech"]["the"] == 11663, test_compute_counts_basic_desc(16, counts["tech"]["the"], "counts[\"tech\"][\"the\"]")
  assert counts["sport"]["the"] == 9646, test_compute_counts_basic_desc(17, counts["sport"]["the"], "counts[\"sport\"][\"the\"]")




from otter.test_files import test_case

OK_FORMAT = False

name = "q2d"
points = 5

def format_error(lines, line, ret_value="", fn_name=""):
  return_str = "\n\n"
  return_str += "The last line of the following test program failed.\n"
  return_str += "Make sure that your function returns exactly the same value\n"
  return_str += "as specified in the <b>assert</b> statement.\n\n"
  
  num_spaces = len(lines[2]) - len(lines[2].strip()) 
  return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
  return_str += "\n<b>"
  return_str += lines[line+1][num_spaces:]
  return_str += "</b>\n\n"
  
  return_str += f"{fn_name} returned:\n"
  return_str += str(ret_value)
  return_str += "\n\n"
  
  return return_str  

                                            


def test_compute_probabilities_desc(line, ret_value, fn_name):
    test_strs = '''
def test_compute_probabilities(compute_probabilities):

  counts = {
      "business": {'quarterly': 17, 'profits': 132, 'at': 908, 'us': 740, 'media': 26, 'giant': 83, 'timewarner': 7, 'jumped': 20, '76%': 2, 'to': 4986},
      "entertainment": {'a': 2732, 'christmas': 62, 'tree': 7, 'that': 738, 'can': 82, 'receive': 23, 'text': 5, 'messages': 3, 'has': 695, 'been': 379},
      "politics": {'maternity': 19, 'pay': 92, 'for': 1889, 'new': 418, 'mothers': 6, 'is': 1828, 'to': 5930, 'rise': 45, 'by': 1005, '£1,400': 1},
      "tech": {'the': 11663, 'kyrgyz': 4, 'republic': 12, 'a': 4335, 'small': 89, 'mountainous': 2, 'state': 32, 'of': 5329, 'former': 19, 'soviet': 2},
      "sport": {'british': 81, 'hurdler': 4, 'sarah': 7, 'claxton': 10, 'is': 1487, 'confident': 51, 'she': 311, 'can': 296, 'win': 384, 'her': 298}
  }

  probs = compute_probabilities(counts)

  assert len(probs) == 5
  assert len(probs["business"]) == 10

  assert probs["business"]["profits"] > 0.01907238838318162 - 0.0001
  assert probs["business"]["profits"] < 0.01907238838318162 + 0.0001
  assert probs["entertainment"]["christmas"] > 0.013118916631400761 - 0.0001
  assert probs["entertainment"]["christmas"] < 0.013118916631400761 + 0.0001
  assert probs["politics"]["maternity"] > 0.0016914448499955488 - 0.0001
  assert probs["politics"]["maternity"] < 0.0016914448499955488 + 0.0001
  assert probs["tech"]["republic"] > 0.0005584772187834505 - 0.0001
  assert probs["tech"]["republic"] < 0.0005584772187834505 + 0.0001
  assert probs["sport"]["hurdler"] > 0.0013656538067599864 - 0.0001
  assert probs["sport"]["hurdler"] < 0.0013656538067599864 + 0.0001





    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)

@test_case(points=5, hidden=False)
def test_compute_probabilities(compute_probabilities):

  counts = {
      "business": {'quarterly': 17, 'profits': 132, 'at': 908, 'us': 740, 'media': 26, 'giant': 83, 'timewarner': 7, 'jumped': 20, '76%': 2, 'to': 4986},
      "entertainment": {'a': 2732, 'christmas': 62, 'tree': 7, 'that': 738, 'can': 82, 'receive': 23, 'text': 5, 'messages': 3, 'has': 695, 'been': 379},
      "politics": {'maternity': 19, 'pay': 92, 'for': 1889, 'new': 418, 'mothers': 6, 'is': 1828, 'to': 5930, 'rise': 45, 'by': 1005, '£1,400': 1},
      "tech": {'the': 11663, 'kyrgyz': 4, 'republic': 12, 'a': 4335, 'small': 89, 'mountainous': 2, 'state': 32, 'of': 5329, 'former': 19, 'soviet': 2},
      "sport": {'british': 81, 'hurdler': 4, 'sarah': 7, 'claxton': 10, 'is': 1487, 'confident': 51, 'she': 311, 'can': 296, 'win': 384, 'her': 298}
  }

  probs = compute_probabilities(counts)

  assert len(probs) == 5, test_compute_probabilities_desc(12, len(probs), "len(probs)")
  assert len(probs["business"]) == 10, test_compute_probabilities_desc(13, len(probs["business"]), "len(probs[\"business\"])")

  assert probs["business"]["profits"] > 0.01907238838318162 - 0.0001, test_compute_probabilities_desc(15, probs["business"]["profits"], "probs[\"business\"][\"profits\"]")
  assert probs["business"]["profits"] < 0.01907238838318162 + 0.0001, test_compute_probabilities_desc(16, probs["business"]["profits"], "probs[\"business\"][\"profits\"]")
  assert probs["entertainment"]["christmas"] > 0.013118916631400761 - 0.0001, test_compute_probabilities_desc(17, probs["entertainment"]["christmas"], "probs[\"entertainment\"][\"christmas\"]")
  assert probs["entertainment"]["christmas"] < 0.013118916631400761 + 0.0001, test_compute_probabilities_desc(18, probs["entertainment"]["christmas"], "probs[\"entertainment\"][\"christmas\"]")
  assert probs["politics"]["maternity"] > 0.0016914448499955488 - 0.0001, test_compute_probabilities_desc(19, probs["politics"]["maternity"], "probs[\"politics\"][\"maternity\"]")
  assert probs["politics"]["maternity"] < 0.0016914448499955488 + 0.0001, test_compute_probabilities_desc(20, probs["politics"]["maternity"], "probs[\"politics\"][\"maternity\"]")
  assert probs["tech"]["republic"] > 0.0005584772187834505 - 0.0001, test_compute_probabilities_desc(21, probs["tech"]["republic"], "probs[\"tech\"][\"republic\"]")
  assert probs["tech"]["republic"] < 0.0005584772187834505 + 0.0001, test_compute_probabilities_desc(22, probs["tech"]["republic"], "probs[\"tech\"][\"republic\"]")
  assert probs["sport"]["hurdler"] > 0.0013656538067599864 - 0.0001, test_compute_probabilities_desc(23, probs["sport"]["hurdler"], "probs[\"sport\"][\"hurdler\"]")
  assert probs["sport"]["hurdler"] < 0.0013656538067599864 + 0.0001, test_compute_probabilities_desc(24, probs["sport"]["hurdler"], "probs[\"sport\"][\"hurdler\"]")






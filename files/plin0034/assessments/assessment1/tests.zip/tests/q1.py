from otter.test_files import test_case

OK_FORMAT = False

name = "q1"
points = 10

def format_error(lines, line, ret_value="", fn_name=""):
  return_str = "\n\n"
  return_str += "The last line of the following test program failed.\n"
  return_str += "Make sure that your function returns exactly the same value\n"
  return_str += "as specified in the <b>assert</b> statement.\n\n"
  
  num_spaces = len(lines[2]) - len(lines[2].strip()) 
  return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
  return_str += "\n<b>"
  return_str += lines[line+1][num_spaces:]
  return_str += "</b>\n\n"
  
  return_str += f"{fn_name} returned:\n"
  return_str += str(ret_value)
  return_str += "\n\n"
  
  return return_str  

                                            


def test_allowed_resources_len_desc(line, ret_value, fn_name):
    test_strs = '''
def test_allowed_resources_len(allowed_resources):
  allowed, forbidden = allowed_resources()
  assert len(allowed) == 5
  assert len(forbidden) == 3

    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)

@test_case(points=5, hidden=False)
def test_allowed_resources_len(allowed_resources):
  allowed, forbidden = allowed_resources()
  assert len(allowed) == 5, test_allowed_resources_len_desc(2, len(allowed), "len(allowed)")
  assert len(forbidden) == 3, test_allowed_resources_len_desc(3, len(forbidden), "len(forbidden)")


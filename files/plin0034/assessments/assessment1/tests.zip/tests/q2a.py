from otter.test_files import test_case

OK_FORMAT = False

name = "q2a"
points = 10

def format_error(lines, line, ret_value="", fn_name=""):
  return_str = "\n\n"
  return_str += "The last line of the following test program failed.\n"
  return_str += "Make sure that your function returns exactly the same value\n"
  return_str += "as specified in the <b>assert</b> statement.\n\n"
  
  num_spaces = len(lines[2]) - len(lines[2].strip()) 
  return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
  return_str += "\n<b>"
  return_str += lines[line+1][num_spaces:]
  return_str += "</b>\n\n"
  
  return_str += f"{fn_name} returned:\n"
  return_str += str(ret_value)
  return_str += "\n\n"
  
  return return_str  

                                            


def read_all_lines_test_basic_desc(line, ret_value, fn_name):
    test_strs = '''

def read_all_lines_test_basic(read_all_lines):
  lines = read_all_lines("data/bayes_theorem.txt")

  assert len(lines) == 3
  assert "Bayes' theorem" in lines[0]

  assert lines[1] == ""
  assert "❌❌❌" in lines[2]

    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)

@test_case(points=5, hidden=False)

def read_all_lines_test_basic(read_all_lines):
  lines = read_all_lines("data/bayes_theorem.txt")

  assert len(lines) == 3, read_all_lines_test_basic_desc(4, len(lines), "len(lines)")
  assert "Bayes' theorem" in lines[0], read_all_lines_test_basic_desc(5, "Bayes' theorem" in lines[0], "\"Bayes' theorem\" in lines[0]")

  assert lines[1] == "", read_all_lines_test_basic_desc(7, lines[1], "lines[1]")
  assert "❌❌❌" in lines[2], read_all_lines_test_basic_desc(8, "❌❌❌" in lines[2], "\"\u274c\u274c\u274c\" in lines[2]")


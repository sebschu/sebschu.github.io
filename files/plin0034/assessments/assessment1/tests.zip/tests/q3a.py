from otter.test_files import test_case

OK_FORMAT = False

name = "q3a"
points = 10

def format_error(lines, line, ret_value="", fn_name=""):
  return_str = "\n\n"
  return_str += "The last line of the following test program failed.\n"
  return_str += "Make sure that your function returns exactly the same value\n"
  return_str += "as specified in the <b>assert</b> statement.\n\n"
  
  num_spaces = len(lines[2]) - len(lines[2].strip()) 
  return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
  return_str += "\n<b>"
  return_str += lines[line+1][num_spaces:]
  return_str += "</b>\n\n"
  
  return_str += f"{fn_name} returned:\n"
  return_str += str(ret_value)
  return_str += "\n\n"
  
  return return_str  

                                            


def test_smoothed_probabilities_basic_desc(line, ret_value, fn_name):
    test_strs = '''
def test_smoothed_probabilities_basic(compute_smoothed_probabilities):
  counts = {
      "business": {'quarterly': 17, 'profits': 132, 'at': 908, 'us': 740, 'media': 26, 'giant': 83, 'timewarner': 7, 'jumped': 20, '76%': 2, 'to': 4986},
      "entertainment": {'a': 2732, 'christmas': 62, 'tree': 7, 'that': 738, 'can': 82, 'receive': 23, 'text': 5, 'messages': 3, 'has': 695, 'been': 379},
      "politics": {'maternity': 19, 'pay': 92, 'for': 1889, 'new': 418, 'mothers': 6, 'is': 1828, 'to': 5930, 'rise': 45, 'by': 1005, '£1,400': 1},
      "tech": {'the': 11663, 'kyrgyz': 4, 'republic': 12, 'a': 4335, 'small': 89, 'mountainous': 2, 'state': 32, 'of': 5329, 'former': 19, 'soviet': 2},
      "sport": {'british': 81, 'hurdler': 4, 'sarah': 7, 'claxton': 10, 'is': 1487, 'confident': 51, 'she': 311, 'can': 296, 'win': 384, 'her': 298}
  }

  probs = compute_smoothed_probabilities(counts)

  assert len(probs) == 5

  assert probs["business"]["profits"] > 0.019089995693985933 - 0.0001
  assert probs["business"]["profits"] < 0.019089995693985933 + 0.0001
  assert probs["entertainment"]["christmas"] > 0.013202011735121543 - 0.0001
  assert probs["entertainment"]["christmas"] < 0.013202011735121543 + 0.0001
  assert probs["politics"]["maternity"] > 0.00177320684457842 - 0.0001
  assert probs["politics"]["maternity"] < 0.00177320684457842 + 0.0001
  assert probs["tech"]["republic"] > 0.0006037245158593786 - 0.0001
  assert probs["tech"]["republic"] < 0.0006037245158593786 + 0.0001
  assert probs["sport"]["hurdler"] > 0.0016806722689075631 - 0.0001
  assert probs["sport"]["hurdler"] < 0.0016806722689075631 + 0.0001


    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)

@test_case(points=5, hidden=False)
def test_smoothed_probabilities_basic(compute_smoothed_probabilities):
  counts = {
      "business": {'quarterly': 17, 'profits': 132, 'at': 908, 'us': 740, 'media': 26, 'giant': 83, 'timewarner': 7, 'jumped': 20, '76%': 2, 'to': 4986},
      "entertainment": {'a': 2732, 'christmas': 62, 'tree': 7, 'that': 738, 'can': 82, 'receive': 23, 'text': 5, 'messages': 3, 'has': 695, 'been': 379},
      "politics": {'maternity': 19, 'pay': 92, 'for': 1889, 'new': 418, 'mothers': 6, 'is': 1828, 'to': 5930, 'rise': 45, 'by': 1005, '£1,400': 1},
      "tech": {'the': 11663, 'kyrgyz': 4, 'republic': 12, 'a': 4335, 'small': 89, 'mountainous': 2, 'state': 32, 'of': 5329, 'former': 19, 'soviet': 2},
      "sport": {'british': 81, 'hurdler': 4, 'sarah': 7, 'claxton': 10, 'is': 1487, 'confident': 51, 'she': 311, 'can': 296, 'win': 384, 'her': 298}
  }

  probs = compute_smoothed_probabilities(counts)

  assert len(probs) == 5, test_smoothed_probabilities_basic_desc(11, len(probs), "len(probs)")

  assert probs["business"]["profits"] > 0.019089995693985933 - 0.0001, test_smoothed_probabilities_basic_desc(13, probs["business"]["profits"], "probs[\"business\"][\"profits\"]")
  assert probs["business"]["profits"] < 0.019089995693985933 + 0.0001, test_smoothed_probabilities_basic_desc(14, probs["business"]["profits"], "probs[\"business\"][\"profits\"]")
  assert probs["entertainment"]["christmas"] > 0.013202011735121543 - 0.0001, test_smoothed_probabilities_basic_desc(15, probs["entertainment"]["christmas"], "probs[\"entertainment\"][\"christmas\"]")
  assert probs["entertainment"]["christmas"] < 0.013202011735121543 + 0.0001, test_smoothed_probabilities_basic_desc(16, probs["entertainment"]["christmas"], "probs[\"entertainment\"][\"christmas\"]")
  assert probs["politics"]["maternity"] > 0.00177320684457842 - 0.0001, test_smoothed_probabilities_basic_desc(17, probs["politics"]["maternity"], "probs[\"politics\"][\"maternity\"]")
  assert probs["politics"]["maternity"] < 0.00177320684457842 + 0.0001, test_smoothed_probabilities_basic_desc(18, probs["politics"]["maternity"], "probs[\"politics\"][\"maternity\"]")
  assert probs["tech"]["republic"] > 0.0006037245158593786 - 0.0001, test_smoothed_probabilities_basic_desc(19, probs["tech"]["republic"], "probs[\"tech\"][\"republic\"]")
  assert probs["tech"]["republic"] < 0.0006037245158593786 + 0.0001, test_smoothed_probabilities_basic_desc(20, probs["tech"]["republic"], "probs[\"tech\"][\"republic\"]")
  assert probs["sport"]["hurdler"] > 0.0016806722689075631 - 0.0001, test_smoothed_probabilities_basic_desc(21, probs["sport"]["hurdler"], "probs[\"sport\"][\"hurdler\"]")
  assert probs["sport"]["hurdler"] < 0.0016806722689075631 + 0.0001, test_smoothed_probabilities_basic_desc(22, probs["sport"]["hurdler"], "probs[\"sport\"][\"hurdler\"]")



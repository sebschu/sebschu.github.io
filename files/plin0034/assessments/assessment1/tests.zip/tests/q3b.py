from otter.test_files import test_case

OK_FORMAT = False

name = "q3b"
points = 10

def format_error(lines, line, ret_value="", fn_name=""):
  return_str = "\n\n"
  return_str += "The last line of the following test program failed.\n"
  return_str += "Make sure that your function returns exactly the same value\n"
  return_str += "as specified in the <b>assert</b> statement.\n\n"
  
  num_spaces = len(lines[2]) - len(lines[2].strip()) 
  return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
  return_str += "\n<b>"
  return_str += lines[line+1][num_spaces:]
  return_str += "</b>\n\n"
  
  return_str += f"{fn_name} returned:\n"
  return_str += str(ret_value)
  return_str += "\n\n"
  
  return return_str  

                                            


def test_categoriser_v2_basic_desc(line, ret_value, fn_name):
    test_strs = '''
def test_categoriser_v2_basic(categorise_text_v2, smoothed_prob_category_word):
  n_cats = len(smoothed_prob_category_word)
  prob_category = {cat: 1 / n_cats for cat in smoothed_prob_category_word}

  assert categorise_text_v2("The company is doing a lot of business.", prob_category, smoothed_prob_category_word) == "business"
  assert categorise_text_v2("She is a star.", prob_category, smoothed_prob_category_word) == "entertainment"
  assert categorise_text_v2("The prime minister.", prob_category, smoothed_prob_category_word) == "politics"
  assert categorise_text_v2("A great technology.", prob_category, smoothed_prob_category_word) == "tech"
  assert categorise_text_v2("They came in first place.", prob_category, smoothed_prob_category_word) == "sport"

    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)

@test_case(points=5, hidden=False)
def test_categoriser_v2_basic(categorise_text_v2, smoothed_prob_category_word):
  n_cats = len(smoothed_prob_category_word)
  prob_category = {cat: 1 / n_cats for cat in smoothed_prob_category_word}

  assert categorise_text_v2("The company is doing a lot of business.", prob_category, smoothed_prob_category_word) == "business", test_categoriser_v2_basic_desc(4, categorise_text_v2("The company is doing a lot of business.", prob_category, smoothed_prob_category_word), "categorise_text_v2(\"The company is doing a lot of business.\", prob_category, smoothed_prob_category_word)")
  assert categorise_text_v2("She is a star.", prob_category, smoothed_prob_category_word) == "entertainment", test_categoriser_v2_basic_desc(5, categorise_text_v2("She is a star.", prob_category, smoothed_prob_category_word), "categorise_text_v2(\"She is a star.\", prob_category, smoothed_prob_category_word)")
  assert categorise_text_v2("The prime minister.", prob_category, smoothed_prob_category_word) == "politics", test_categoriser_v2_basic_desc(6, categorise_text_v2("The prime minister.", prob_category, smoothed_prob_category_word), "categorise_text_v2(\"The prime minister.\", prob_category, smoothed_prob_category_word)")
  assert categorise_text_v2("A great technology.", prob_category, smoothed_prob_category_word) == "tech", test_categoriser_v2_basic_desc(7, categorise_text_v2("A great technology.", prob_category, smoothed_prob_category_word), "categorise_text_v2(\"A great technology.\", prob_category, smoothed_prob_category_word)")
  assert categorise_text_v2("They came in first place.", prob_category, smoothed_prob_category_word) == "sport", test_categoriser_v2_basic_desc(8, categorise_text_v2("They came in first place.", prob_category, smoothed_prob_category_word), "categorise_text_v2(\"They came in first place.\", prob_category, smoothed_prob_category_word)")


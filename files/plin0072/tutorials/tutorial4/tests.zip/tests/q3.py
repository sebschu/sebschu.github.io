from otter.test_files import test_case

OK_FORMAT = False

name = "q3"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_dataclass_desc(line, ret_value, fn_name):
    test_strs = '''
def test_dataclass(train_dataset):
    assert len(train_dataset) == 204579
    x1, y1 = train_dataset[0]
    x2, y2 = train_dataset[1]
    assert x1.tolist() == [[400000, 400000, 318, 11, 34408]]
    assert len(y1.tolist()) == 1
    assert x2.tolist() == [[400000, 318, 11, 34408, 45]]
    assert len(y2.tolist()) == 1
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_dataclass(train_dataset):
    assert len(train_dataset) == 204579, test_dataclass_desc(1, len(train_dataset), "len(train_dataset)")
    x1, y1 = train_dataset[0]
    x2, y2 = train_dataset[1]
    assert x1.tolist() == [[400000, 400000, 318, 11, 34408]], test_dataclass_desc(4, x1.tolist(), "x1.tolist()")
    assert len(y1.tolist()) == 1, test_dataclass_desc(5, len(y1.tolist()), "len(y1.tolist())")
    assert x2.tolist() == [[400000, 318, 11, 34408, 45]], test_dataclass_desc(6, x2.tolist(), "x2.tolist()")
    assert len(y2.tolist()) == 1, test_dataclass_desc(7, len(y2.tolist()), "len(y2.tolist())")


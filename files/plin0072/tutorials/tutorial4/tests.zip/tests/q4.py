from otter.test_files import test_case

OK_FORMAT = False

name = "q4"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_model_desc(line, ret_value, fn_name):
    test_strs = '''
def test_model(FeedForwardTagger, embeddings):
    import torch
    model = FeedForwardTagger(5 * NO_OF_DIMENSIONS, 10, 10, embeddings)
    total_params = sum((p.numel() for p in model.parameters()))
    assert total_params == 120015720
    y = model(torch.LongTensor([[1, 2, 3, 4, 5], [400000, 318, 11, 34408, 45]]))
    assert y.size()[0] == 2
    assert y.size()[1] == 10
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_model(FeedForwardTagger, embeddings):
    import torch
    model = FeedForwardTagger(5 * NO_OF_DIMENSIONS, 10, 10, embeddings)
    total_params = sum((p.numel() for p in model.parameters()))
    assert total_params == 120015720, test_model_desc(4, total_params, "total_params")
    y = model(torch.LongTensor([[1, 2, 3, 4, 5], [400000, 318, 11, 34408, 45]]))
    assert y.size()[0] == 2, test_model_desc(6, y.size()[0], "y.size()[0]")
    assert y.size()[1] == 10, test_model_desc(7, y.size()[1], "y.size()[1]")


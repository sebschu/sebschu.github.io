from otter.test_files import test_case

OK_FORMAT = False

name = "q1"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_load_word_vectors_desc(line, ret_value, fn_name):
    test_strs = '''
def test_load_word_vectors(embeddings):
    assert embeddings.shape == (400002, 300)
    assert embeddings[0, 1:20].tolist() == [0.21318, -0.0074364, -0.45854, -0.035639, 0.23643, -0.28836, 0.21521, -0.13486, -1.6413, -0.26091, 0.032434, 0.056621, -0.043296, -0.021672, 0.22476, -0.075129, -0.067018, -0.14247, 0.038825]
    assert embeddings[400001, 1:20].tolist() == [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_load_word_vectors(embeddings):
    assert embeddings.shape == (400002, 300), test_load_word_vectors_desc(1, embeddings.shape, "embeddings.shape")
    assert embeddings[0, 1:20].tolist() == [0.21318, -0.0074364, -0.45854, -0.035639, 0.23643, -0.28836, 0.21521, -0.13486, -1.6413, -0.26091, 0.032434, 0.056621, -0.043296, -0.021672, 0.22476, -0.075129, -0.067018, -0.14247, 0.038825], test_load_word_vectors_desc(2, embeddings[0, 1:20].tolist(), "embeddings[0, 1:20].tolist()")
    assert embeddings[400001, 1:20].tolist() == [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], test_load_word_vectors_desc(3, embeddings[400001, 1:20].tolist(), "embeddings[400001, 1:20].tolist()")


def test_word2index_desc(line, ret_value, fn_name):
    test_strs = '''
def test_word2index(word2index):
    assert len(word2index) == 400002
    assert word2index['the'] == 0
    assert word2index['cat'] == 5450
    assert word2index['mat'] == 14948
    assert word2index['sat'] == 3223
    assert word2index['-UNK-'] == 400000
    assert word2index['-NONE-'] == 400001
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_word2index(word2index):
    assert len(word2index) == 400002, test_word2index_desc(1, len(word2index), "len(word2index)")
    assert word2index['the'] == 0, test_word2index_desc(2, word2index['the'], "word2index['the']")
    assert word2index['cat'] == 5450, test_word2index_desc(3, word2index['cat'], "word2index['cat']")
    assert word2index['mat'] == 14948, test_word2index_desc(4, word2index['mat'], "word2index['mat']")
    assert word2index['sat'] == 3223, test_word2index_desc(5, word2index['sat'], "word2index['sat']")
    assert word2index['-UNK-'] == 400000, test_word2index_desc(6, word2index['-UNK-'], "word2index['-UNK-']")
    assert word2index['-NONE-'] == 400001, test_word2index_desc(7, word2index['-NONE-'], "word2index['-NONE-']")


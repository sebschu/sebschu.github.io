from otter.test_files import test_case

OK_FORMAT = False

name = "q7"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_accuracy_desc(line, ret_value, fn_name):
    test_strs = '''
def test_accuracy(correct, eval_preds_vector):
    assert correct == 23424
    assert eval_preds_vector[0:10].tolist() == ['ADP', 'DET', 'NOUN', 'VERB', 'DET', 'NOUN', 'PUNCT', 'PROPN', 'PROPN', 'ADP']
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_accuracy(correct, eval_preds_vector):
    assert correct == 23424, test_accuracy_desc(1, correct, "correct")
    assert eval_preds_vector[0:10].tolist() == ['ADP', 'DET', 'NOUN', 'VERB', 'DET', 'NOUN', 'PUNCT', 'PROPN', 'PROPN', 'ADP'], test_accuracy_desc(2, eval_preds_vector[0:10].tolist(), "eval_preds_vector[0:10].tolist()")


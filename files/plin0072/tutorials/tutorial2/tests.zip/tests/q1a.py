from otter.test_files import test_case

OK_FORMAT = False

name = "q1a"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_load_word_vectors_desc(line, ret_value, fn_name):
    test_strs = '''
def test_load_word_vectors(embeddings):
    assert embeddings.shape == (400000, 50)
    assert embeddings[0, 1:20].tolist() == [0.24968, -0.41242, 0.1217, 0.34527, -0.044457, -0.49688, -0.17862, -0.00066023, -0.6566, 0.27843, -0.14767, -0.55677, 0.14658, -0.0095095, 0.011658, 0.10204, -0.12792, -0.8443, -0.12181]
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_load_word_vectors(embeddings):
    assert embeddings.shape == (400000, 50), test_load_word_vectors_desc(1, embeddings.shape, "embeddings.shape")
    assert embeddings[0, 1:20].tolist() == [0.24968, -0.41242, 0.1217, 0.34527, -0.044457, -0.49688, -0.17862, -0.00066023, -0.6566, 0.27843, -0.14767, -0.55677, 0.14658, -0.0095095, 0.011658, 0.10204, -0.12792, -0.8443, -0.12181], test_load_word_vectors_desc(2, embeddings[0, 1:20].tolist(), "embeddings[0, 1:20].tolist()")

